const fs = require('fs');

const d3_cat10 = ["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b","#e377c2","#7f7f7f","#bcbd22","#17becf"];
const d3_cat20a = ["#1f77b4","#aec7e8","#ff7f0e","#ffbb78","#2ca02c","#98df8a","#d62728","#ff9896","#9467bd","#c5b0d5","#8c564b","#c49c94","#e377c2","#f7b6d2","#7f7f7f","#c7c7c7","#bcbd22","#dbdb8d","#17becf","#9edae5"];
const d3_cat20b = ["#393b79","#5254a3","#6b6ecf","#9c9ede","#637939","#8ca252","#b5cf6b","#cedb9c","#8c6d31","#bd9e39","#e7ba52","#e7cb94","#843c39","#ad494a","#d6616b","#e7969c","#7b4173","#a55194","#ce6dbd","#de9ed6"];
const d3_cat20c = ["#3182bd","#6baed6","#9ecae1","#c6dbef","#e6550d","#fd8d3c","#fdae6b","#fdd0a2","#31a354","#74c476","#a1d99b","#c7e9c0","#756bb1","#9e9ac8","#bcbddc","#dadaeb","#636363","#969696","#bdbdbd","#d9d9d9"];

// TODO use cyclical color schemes? https://observablehq.com/@d3/color-schemes

const parentSetsFileName = './inquirer_parent_sets.json';
const parentSetsFile = fs.readFileSync(parentSetsFileName, {encoding: 'utf-8'});

const parentSets = JSON.parse(parentSetsFile);

const tsvFileName = './inquireraugmented.tsv';
const tsvFile = fs.readFileSync(tsvFileName, {encoding: 'utf-8'});

const lines = tsvFile.split("\r\n");

const sets = {};

Object.keys(parentSets).forEach(set => sets[set] = {});

const orphanCategories = [];

lines.forEach((line, i) => {
    if (i > 0) { // skip header
        line = line.trim();
        if (line.length > 0) {
            const entry = line.split("\t");
            const term = entry[0].split('#')[0];
            entry.forEach((category, j) => {
                if (j > 1 && j < 184 && category.length > 0) {
                    const matchingSets = Object.entries(parentSets).filter(([pSet, setCats]) => setCats.indexOf(category) !== -1).map(([pSet, setCats]) => pSet);
                    if (matchingSets.length === 0) {
                        if (orphanCategories.indexOf(category) === -1) {
                            orphanCategories.push(category);
                        }
                    } else {
                        matchingSets.forEach(pSet => {
                            const lcTerm = term.toLowerCase();

                            if (sets[pSet][category] === undefined) {
                                sets[pSet][category] = [];
                            }
                            if (sets[pSet][category].indexOf(lcTerm) === -1) {
                                sets[pSet][category].push(lcTerm);
                            }
                        });
                    }
                }
            })
        }
    }
});

// console.warn("Orphan categories: ", orphanCategories.join(', '))

console.log(Object.keys(sets));

Object.keys(sets).forEach((set) => {
    const entry = sets[set];
    
    const color = {};
    Object.keys(entry).forEach((category, i, allCats) => {
        if (allCats.length > 10) {
            color[category] = d3_cat20a[i % 20];
        } else {
            color[category] = d3_cat10[i % 10];
        }
    });

    const output = {
        credits: "General Inquirer tag categories, from https://inquirer.sites.fas.harvard.edu/homecat.htm",
        categories: entry,
        features: {
            color: color
        }
    }

    fs.writeFileSync(`./categories.h_${set}.txt`, JSON.stringify(output));
});